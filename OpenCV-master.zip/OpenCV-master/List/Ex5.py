#Program Without using List
# Name1 = 'Zophie'
# Name2 = 'Pooka'
# Name3 = 'Simon'
# Name4 = 'Lady Macbeth'
# Name5 = 'Fat-tail'
# Name6 = 'Miss Cleo'

print('Enter the name of cat 1:')
Name1 = input()
print('Enter the name of cat 2:')
Name2 = input()
print('Enter the name of cat 3:')
Name3 = input()
print('Enter the name of cat 4:')
Name4 = input()
print('Enter the name of cat 5:')
Name5 = input()
print('Enter the name of cat 6:')
Name6 = input()
print('The cat names are:')
print(Name1 + ' ' + Name2 + ' ' + Name3 + ' ' + Name4 + ' ' +
Name5 + ' ' + Name6)