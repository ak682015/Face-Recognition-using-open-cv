#Negative Indexes

spam = ['cat', 'bat', 'rat', 'elephant']
print(spam[-1])

print(spam[-3])

print('The ' + spam[-1] + ' is afraid of the ' + spam[-3] + '.')

#Sublists with Slices

spam = ['cat', 'bat', 'rat', 'elephant']
print(spam[0:4])

print(spam[1:3])

print(spam[0:-1])

print(spam[:2])

print(spam[1:])

print(spam[-1])