#Same type of data
print([1, 2, 3])

print(['cat', 'bat', 'rat', 'elephant'])
print("\n")

#Diffrent type of data
print(['hello', 3.1415, True, None, 42])
print("\n")

#List saved in a variable
spam = ['cat', 'bat', 'rat', 'elephant']

print(spam)
