spam = ['cat', 'bat', 'rat', 'elephant']

print(spam[0])

print(spam[1])

print(spam[2])

print(spam[3])

print('Hello ' + spam[0])

print('The ' + spam[1] + ' ate the ' + spam[0] + '.')

#print(spam[1.0])

print(spam[int(1.0)])


#Multidimentional List
spam1 = [['cat', 'bat'], [10, 20, 30, 40, 50]]

print(spam1[0])

print(spam1[0][1])
print(spam1[1][4])
